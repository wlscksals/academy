const min = document.querySelector(".min");
const over = document.querySelector(".over");
const rbtn = document.querySelector(".right");
const lbtn = document.querySelector(".left");
const list = document.querySelector(".see");

const listW = list.clientWidth


const minW = min.clientWidth;
const overW = over.clientWidth;
const a =  overW / minW;
const gap = (minW-listW*3)/3
let b = 1
const totalW = gap+listW;

rbtn.addEventListener("click", () => {
  console.log(a);
  if (b < 4) {
    over.style.transform = `translateX( -${(totalW*3)*b}px)`;

    b++;
  }
  console.log(a);
});

lbtn.addEventListener("click", () => {
  // over.style.transform =
});


// function overleft(minW) {
//   console.log("click...");
//   console.log(minW);
//   over.style.transform = `translateX(+${a}px)`;
// }
